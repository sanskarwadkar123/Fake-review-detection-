import streamlit as st
import joblib
from src.preprocess import clean_text

# Load model and vectorizer
model = joblib.load("model/model.pkl")
vectorizer = joblib.load("model/vectorizer.pkl")

st.set_page_config(page_title="Fake Review Detector", page_icon="🕵️", layout="centered")

st.markdown("""
    <h1 style='text-align:center; color:#4CAF50;'>🕵️ Fake Review Detector</h1>
    <p style='text-align:center; font-size:18px;'>Enter a product review and the model will tell you if it's <b>REAL</b> or <b>FAKE</b>.</p>
""", unsafe_allow_html=True)

review_text = st.text_area("✍️ Write your review here:", height=150)

if st.button("🔍 Analyze Review"):
    if review_text.strip() == "":
        st.warning("Please enter a review to analyze.")
    else:
        cleaned = clean_text(review_text)
        vec = vectorizer.transform([cleaned])
        prediction = model.predict(vec)[0]

        if prediction == "FAKE":
            st.error("🔴 This review is likely **FAKE**!")
        else:
            st.success("🟢 This review looks **REAL**!")

st.markdown("<br><hr>", unsafe_allow_html=True)

st.markdown("""
    <p style='text-align:center; font-size:14px; color:gray;'>
    Created by <b>Babu Bihari</b> 🧠 using Machine Learning
    </p>
""", unsafe_allow_html=True)
