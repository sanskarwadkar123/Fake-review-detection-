# ------------------------------------------------------------
# STREAMLIT APP FOR FAKE REVIEW DETECTOR
# ------------------------------------------------------------

import streamlit as st
import pickle
import os

# ------------------------------------------------------------
# 1. LOAD MODEL & VECTORIZER
# ------------------------------------------------------------
model_path = "../model/model.pkl"
vectorizer_path = "../model/vectorizer.pkl"

if not os.path.exists(model_path) or not os.path.exists(vectorizer_path):
    st.error("Model not found. Please run train_model.py first.")
else:
    model = pickle.load(open(model_path, "rb"))
    vectorizer = pickle.load(open(vectorizer_path, "rb"))

# ------------------------------------------------------------
# 2. UI TITLE
# ------------------------------------------------------------
st.title("🔍 Fake Review Detector")

st.write("Enter a product review and the model will tell if it's fake or real.")

# ------------------------------------------------------------
# 3. INPUT TEXT
# ------------------------------------------------------------
review_text = st.text_area("Review Text:", height=150)

# ------------------------------------------------------------
# 4. PREDICT BUTTON
# ------------------------------------------------------------
if st.button("Analyze Review"):

    if review_text.strip() == "":
        st.warning("Please enter a review before predicting.")
    else:
        text_vec = vectorizer.transform([review_text])
        pred = model.predict(text_vec)[0]

        if pred == 1:
            st.error("🚨 Fake Review Detected!")
        else:
            st.success("✅ Real Review Detected!")

# ------------------------------------------------------------
# END
# ------------------------------------------------------------
