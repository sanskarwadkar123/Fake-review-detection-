# ------------------------------------------------------------
# TRAIN MODEL FOR FAKE REVIEW DETECTOR
# ------------------------------------------------------------

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
import pickle
import os

# ------------------------------------------------------------
# 1. LOAD DATASET
# ------------------------------------------------------------
df = pd.read_csv("../data/fake reviews dataset.csv")

# Remove missing rows
df = df.dropna(subset=["text", "label"])

# ------------------------------------------------------------
# 2. MAP LABELS
# CG → 1 (fake review)
# OR → 0 (real review)
# ------------------------------------------------------------
df["label"] = df["label"].map({"CG": 1, "OR": 0})

# ------------------------------------------------------------
# 3. SPLIT DATA
# ------------------------------------------------------------
X = df["text"]
y = df["label"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# ------------------------------------------------------------
# 4. TF-IDF VECTORIZER
# ------------------------------------------------------------
vectorizer = TfidfVectorizer(stop_words="english", max_features=5000)

X_train_vec = vectorizer.fit_transform(X_train)
X_test_vec = vectorizer.transform(X_test)

# ------------------------------------------------------------
# 5. TRAIN MODEL
# ------------------------------------------------------------
model = LogisticRegression(max_iter=3000)
model.fit(X_train_vec, y_train)

# ------------------------------------------------------------
# 6. CHECK MODEL ACCURACY
# ------------------------------------------------------------
pred = model.predict(X_test_vec)
print("\nModel Accuracy:", accuracy_score(y_test, pred), "\n")

# ------------------------------------------------------------
# 7. SAVE MODEL + VECTORIZER
# ------------------------------------------------------------

os.makedirs("../model", exist_ok=True)

pickle.dump(model, open("../model/model.pkl", "wb"))
pickle.dump(vectorizer, open("../model/vectorizer.pkl", "wb"))

print("Model saved to: ../model/model.pkl")
print("Vectorizer saved to: ../model/vectorizer.pkl")
print("\nTraining Completed Successfully! 🎉")
