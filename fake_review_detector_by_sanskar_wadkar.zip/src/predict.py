# ------------------------------------------------------------
# PREDICT FAKE OR REAL REVIEW USING TRAINED MODEL
# ------------------------------------------------------------

import pickle
import os

# ------------------------------------------------------------
# 1. LOAD MODEL & VECTORIZER
# ------------------------------------------------------------
model_path = "../model/model.pkl"
vectorizer_path = "../model/vectorizer.pkl"

if not os.path.exists(model_path) or not os.path.exists(vectorizer_path):
    raise FileNotFoundError("Model or vectorizer not found. Run train_model.py first.")

model = pickle.load(open(model_path, "rb"))
vectorizer = pickle.load(open(vectorizer_path, "rb"))

# ------------------------------------------------------------
# 2. PREDICTION FUNCTION
# ------------------------------------------------------------
def predict_review(text: str):
    """
    Predicts whether a given review is REAL or FAKE.
    Returns:
        'Fake Review' if label = 1
        'Real Review' if label = 0
    """
    text_vector = vectorizer.transform([text])
    prediction = model.predict(text_vector)[0]

    return "Fake Review" if prediction == 1 else "Real Review"


# ------------------------------------------------------------
# 3. TEST (optional)
# ------------------------------------------------------------
if __name__ == "__main__":
    sample = "This product is amazing!"
    print(sample, "→", predict_review(sample))
